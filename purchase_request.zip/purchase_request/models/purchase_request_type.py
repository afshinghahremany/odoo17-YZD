from odoo import models, fields, api, _

class PurchaseRequestType(models.Model):
    _name = 'purchase.request.type'
    _description = 'Purchase Request Type'

    name = fields.Char(string='عنوان', required=True)
    approver_id = fields.Many2one('res.users', string='تایید کننده', required=True)
    manual_creation = fields.Boolean(string='امکان ثبت دستی', default=True,
                                   help='اگر این گزینه فعال باشد، کاربران می‌توانند این نوع درخواست را به صورت دستی ثبت کنند')
    active = fields.Boolean(default=True)
